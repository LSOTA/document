﻿Install-windowsfeature -name AD-Domain-Services -IncludeManagementTools
