New-ADOrganizationalUnit -Name "Vlora" -Path "dc=leo-19,DC=fr"
New-ADOrganizationalUnit -Name "Fiere" -Path "dc=leo-19,DC=fr"
New-ADOrganizationalUnit -Name "Shkoder" -Path "dc=leo-19,DC=fr"