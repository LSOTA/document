Get-NetIPInterface

New-NetIPAddress -InterfaceIndex 4 -IPAddress 192.168.24.200 -PrefixLength 24 -DefaultGateway 192.168.24.254

pause

